from fastapi import FastAPI
from pydantic import BaseModel
from typing import Any, Dict, List
from .engine import GraphEngine
from .tools import get_tool_registry
from .workflows import code_review_workflow_spec

app = FastAPI(title="Workflow Engine")

tools = get_tool_registry()
engine = GraphEngine(tools=tools)


class GraphCreateRequest(BaseModel):
    start_node: str
    nodes: List[Dict[str, Any]]


class GraphCreateResponse(BaseModel):
    graph_id: str


class GraphRunRequest(BaseModel):
    graph_id: str
    initial_state: Dict[str, Any]


class GraphRunResponse(BaseModel):
    run_id: str
    final_state: Dict[str, Any]
    logs: List[Dict[str, Any]]


@app.post("/graph/create", response_model=GraphCreateResponse)
def create_graph(body: GraphCreateRequest):
    graph_id = engine.create_graph(body.nodes, body.start_node)
    return GraphCreateResponse(graph_id=graph_id)


@app.post("/graph/run", response_model=GraphRunResponse)
def run_graph(body: GraphRunRequest):
    run = engine.run_graph(body.graph_id, body.initial_state)
    return GraphRunResponse(
        run_id=run.id,
        final_state=run.final_state.dict() if run.final_state else {},
        logs=[log.dict() for log in run.logs],
    )


@app.get("/graph/state/{run_id}")
def get_run_state(run_id: str):
    run = engine.get_run_state(run_id)
    return run.dict()


@app.post("/graph/create_example/code_review", response_model=GraphCreateResponse)
def create_example_code_review():
    spec = code_review_workflow_spec()
    graph_id = engine.create_graph(spec["nodes"], spec["start_node"])
    return GraphCreateResponse(graph_id=graph_id)
