# Workflow Engine Assignment

## How to run

1. Create and activate a virtual environment.
2. Install dependencies:
   - `pip install fastapi uvicorn pydantic`
3. Start the server from the project root:
   - `uvicorn app.main:app --reload`
4. Open `http://127.0.0.1:8000/docs` to test the APIs.

## What the workflow engine supports

- Nodes as Python functions operating on a shared Pydantic state.
- A graph of nodes with a configurable start node.
- Sequential execution with a shared state passed between nodes.
- Simple loop using a node that repeats until a state condition is satisfied.
- Example workflow: a code review mini-agent that:
  - extracts functions,
  - checks complexity,
  - detects issues,
  - suggests improvements,
  - computes a quality score and loops until a threshold.

## What I would improve with more time

- Persist graphs and runs in a real database instead of in-memory.
- Add better logging and error handling.
- Add support for async tools and long-running steps.
- Add more flexible branching and richer graph definitions via API.
